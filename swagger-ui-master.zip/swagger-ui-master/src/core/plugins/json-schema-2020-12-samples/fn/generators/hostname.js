/**
 * @prettier
 */
const hostnameGenerator = () => "example.com"

export default hostnameGenerator
