/**
 * @prettier
 */
const uriTemplateGenerator = () =>
  "https://example.com/dictionary/{term:1}/{term}"

export default uriTemplateGenerator
